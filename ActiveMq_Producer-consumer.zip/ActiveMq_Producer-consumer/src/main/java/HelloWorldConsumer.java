import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.springframework.messaging.handler.MessageCondition;

public class HelloWorldConsumer {
	
	public static void main(String[] args)
	{
	
     ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://ZIPLSY755:61616");
		
		Connection connection ;
		
		
			try{
			 connection = connectionFactory.createConnection();
			connection.start();

			Session session = connection.createSession(false,Session.AUTO_ACKNOWLEDGE);
			
			
			Destination destination = session.createQueue("HelloWorldQueue");
			
			
	        MessageConsumer  consumer = session.createConsumer(destination);
			
			Message message = consumer.receive(1000);
			
			if(message instanceof TextMessage)
			{
				TextMessage textMessage = (TextMessage) message;
				
				String text = textMessage.getText();
				System.out.println("Recieved: "+text);
			}else 
			{
				System.out.println("Recieved: "+message);
			}
			consumer.close();
			session.close();
			connection.close();
			
	
			}catch(JMSException e)
			{
				e.printStackTrace();
			}
	
	
	}

}
