import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;


public class HelloWorldProducer {
	
	public static void main (String[] args)
	{
	
		
		
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:61616");
		
		Connection connection ;
		
		try {
			
			 connection = connectionFactory.createConnection();
			connection.start();

			Session session = connection.createSession(false,Session.AUTO_ACKNOWLEDGE);
			
			
			Destination destination = session.createQueue("HelloWorldQueue");
			
			
			MessageProducer producer = session.createProducer(destination);
			producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
			
			String message = "Hello I am using ActiveMQ "+ Thread.currentThread().getName();
			TextMessage textMessage = session.createTextMessage(message);
			
			
			producer.send(textMessage);
			
			
			session.close();
			
			connection.close();
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
